# Assignment 2 - Stock Ticker with Sass and MDBootstrap

Please read the instructions in the [assignment PDF](dmit2008-assignment-02-fall-2020.pdf)

Any other instructions should be specified by your instructor.
