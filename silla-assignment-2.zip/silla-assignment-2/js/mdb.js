var ctxL = document.getElementById("lineChart").getContext('2d');

    var gradientFill = ctxL.createLinearGradient(0, 0, 0, 290);

    gradientFill.addColorStop(0, "rgba(173, 53, 186, 1)");

    gradientFill.addColorStop(1, "rgba(173, 53, 186, 0.1)");

    var myLineChart = new Chart(ctxL, {

      type: 'line',

      data: {

        labels: ["open", "high", "low", "price", "previous close"],

        datasets: [

          {

            label: "MFT in USD",

            data: [198.5, 199.0, 194, 195, 196],

            backgroundColor: gradientFill,

            borderColor: [

              '#AD35BA',

            ],

            borderWidth: 2,

            pointBorderColor: "#fff",

            pointBackgroundColor: "rgba(173, 53, 186, 0.1)",

          }

        ]

      },

      options: {

        responsive: true

      }

    });